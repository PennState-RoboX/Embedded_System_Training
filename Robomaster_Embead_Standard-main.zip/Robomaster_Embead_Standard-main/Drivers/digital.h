#ifndef  __Digital_H
#define __Digital_H
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"

void digital_init(void);

#endif // DIGITAL_H_INCLUDED
